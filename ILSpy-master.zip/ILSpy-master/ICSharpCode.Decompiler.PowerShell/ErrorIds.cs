﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICSharpCode.Decompiler.PowerShell
{
	public static class ErrorIds
	{
		public static readonly string AssemblyLoadFailed = "1";
		public static readonly string DecompilationFailed = "2";
	}
}
